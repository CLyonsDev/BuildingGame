#if !UNITY_5_2
using UnityEngine;
using System.Collections;
using System;
using System.IO;

[HelpURL("http://grabblesgame.com/nat-traversal/docs/class_n_a_t_traversal_1_1_network_manager.html")]
public class AdvancedMigrationManager : NATTraversal.MigrationManager
{
}
#endif
